package com.example.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class EmployeeRepository(private val database: AppDatabase) {

    private val employeeDao = database.employeeDao()
    private val attendanceDao = database.attendanceDao()
    private val settingDao = database.settingDao()

    // Employees
    val allEmployees: Flow<List<Employee>> = employeeDao.getAllEmployees()
    val activeEmployees: Flow<List<Employee>> = employeeDao.getActiveEmployees()

    suspend fun getEmployeeById(id: Int): Employee? = employeeDao.getEmployeeById(id)
    
    suspend fun getEmployeeByCode(code: String): Employee? = employeeDao.getEmployeeByCode(code)

    suspend fun insertEmployee(employee: Employee): Long = employeeDao.insertEmployee(employee)

    suspend fun deleteEmployee(id: Int) = employeeDao.deleteEmployee(id)

    // Logs
    val allLogs: Flow<List<AttendanceLog>> = attendanceDao.getAllLogs()

    fun getLogsByDate(dateString: String): Flow<List<AttendanceLog>> = attendanceDao.getLogsByDate(dateString)

    fun getLogsByEmployee(employeeId: String): Flow<List<AttendanceLog>> = attendanceDao.getLogsByEmployee(employeeId)

    suspend fun clearAllLogs() = attendanceDao.clearAllLogs()
    
    suspend fun insertLogDirect(log: AttendanceLog) = attendanceDao.insertLog(log)

    // Settings
    val appSetting: Flow<AppSetting?> = settingDao.getSetting()

    suspend fun getSettingDirect(): AppSetting? = settingDao.getSettingDirect()

    suspend fun saveSetting(setting: AppSetting) = settingDao.saveSetting(setting)

    /**
     * core Attendance Registration Logic:
     * Automatically determines if this is "حضور" (Check-in) or "انصراف" (Check-out) for the employee today,
     * calculates whether they are late/early/regular based on current school settings,
     * and logs the transaction.
     */
    suspend fun logAttendance(employeeId: String, currentTimestamp: Long = System.currentTimeMillis()): LogResult {
        val employee = employeeDao.getEmployeeByCode(employeeId) ?: return LogResult.Error("الموظفة غير مسجلة في النظام")
        
        if (!employee.isActive) {
            return LogResult.Error("ملف الموظفة موقوف حالياً. يرجى مراجعة الإدارة.")
        }

        // Format dates
        val dateSdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val timeSdf = SimpleDateFormat("HH:mm", Locale.US)
        val dateStr = dateSdf.format(currentTimestamp)
        val timeStr = timeSdf.format(currentTimestamp)

        // Fetch current logs for today to determine if check-in or check-out
        val todayLogs = attendanceDao.getEmployeeLogsForDate(employeeId, dateStr)
        
        val logType: String
        if (todayLogs.isEmpty()) {
            logType = "حضور"
        } else if (todayLogs.size == 1 && todayLogs[0].type == "حضور") {
            logType = "انصراف"
        } else {
            // Already checked in and checked out today
            // Allow logging another "انصراف" or updating it, or just make it another "انصراف"
            logType = "انصراف"
        }

        // Get settings to evaluate status
        val settings = getSettingDirect() ?: AppSetting()
        
        val status: String
        if (logType == "حضور") {
            // Check if late (متأخر)
            status = calculateCheckInStatus(timeStr, settings.workStartTime, settings.gracePeriodMinutes)
        } else {
            // Check if early checkout (انصراف مبكر)
            status = calculateCheckOutStatus(timeStr, settings.workEndTime)
        }

        val newLog = AttendanceLog(
            employeeId = employeeId,
            employeeName = employee.name,
            timestamp = currentTimestamp,
            dateString = dateStr,
            type = logType,
            status = status
        )

        attendanceDao.insertLog(newLog)

        return LogResult.Success(newLog, employee)
    }

    private fun calculateCheckInStatus(checkInTime: String, workStartTime: String, gracePeriod: Int): String {
        try {
            val format = SimpleDateFormat("HH:mm", Locale.US)
            val checkInDate = format.parse(checkInTime) ?: return "منتظم"
            val workStartDate = format.parse(workStartTime) ?: return "منتظم"

            val cal = Calendar.getInstance()
            cal.time = workStartDate
            cal.add(Calendar.MINUTE, gracePeriod)
            val lateThreshold = cal.time

            return if (checkInDate.after(lateThreshold)) {
                "متأخر"
            } else {
                "منتظم"
            }
        } catch (e: Exception) {
            return "منتظم"
        }
    }

    private fun calculateCheckOutStatus(checkOutTime: String, workEndTime: String): String {
        try {
            val format = SimpleDateFormat("HH:mm", Locale.US)
            val checkOutDate = format.parse(checkOutTime) ?: return "منتظم"
            val workEndDate = format.parse(workEndTime) ?: return "منتظم"

            return if (checkOutDate.before(workEndDate)) {
                "انصراف مبكر"
            } else {
                "منتظم"
            }
        } catch (e: Exception) {
            return "منتظم"
        }
    }
}

sealed class LogResult {
    data class Success(val log: AttendanceLog, val employee: Employee) : LogResult()
    data class Error(val message: String) : LogResult()
}
