package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,             // الاسم الكامل
    val employeeId: String,       // الرقم الوظيفي (Unique)
    val department: String,       // القسم
    val jobTitle: String,         // المسمى الوظيفي
    val phone: String,            // رقم الهاتف
    val photoUri: String? = null, // مسار الصورة أو اسم الأفاتار الافتراضي
    val isActive: Boolean = true, // فعال / موقوف
    val hireDate: String,         // تاريخ التعيين
    val notes: String = "",       // ملاحظات
    val isBiometricLinked: Boolean = false // هل تم ربط البصمة بنجاح؟
)

@Entity(tableName = "attendance_logs")
data class AttendanceLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val employeeId: String,       // الرقم الوظيفي للموظفة
    val employeeName: String,     // اسم الموظفة
    val timestamp: Long,          // تاريخ وقت العملية بالملي ثانية
    val dateString: String,       // صيغة تاريخ اليوم (yyyy-MM-dd)
    val type: String,             // "حضور" أو "انصراف"
    val status: String            // "منتظم" أو "متأخر" أو "انصراف مبكر"
)

@Entity(tableName = "settings")
data class AppSetting(
    @PrimaryKey val id: Int = 1,
    val schoolName: String = "مدرسة النهى الابتدائية للبنات",
    val schoolLogoSeed: Int = 2,  // محاكاة شعار المدرسة عبر أشكال هندسية مدمجة جميلة
    val workStartTime: String = "07:30", // وقت الحضور
    val workEndTime: String = "13:30",   // وقت الانصراف
    val gracePeriodMinutes: Int = 15,    // فترة السماح بالدقائق
    val weekendDays: String = "الجمعة,السبت", // عطلة نهاية الأسبوع
    val selectedThemeIndex: Int = 0,     // 0 = وردي النهى (رسمي)، 1 = زمردي، 2 = كحلي، 3 = كلاسيك
    val appLockEnabled: Boolean = false, // قفل التطبيق بالبصمة أو الرمز
    val appLockPin: String = "1234",     // رمز PIN الافتراضي
    val preventScreenshots: Boolean = true // حظر لقطات الشاشة للأمان والخصوصية
)
