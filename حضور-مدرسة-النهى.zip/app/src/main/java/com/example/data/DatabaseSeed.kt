package com.example.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object DatabaseSeed {
    suspend fun seedIfNeeded(
        employeeDao: EmployeeDao,
        attendanceDao: AttendanceDao,
        settingDao: SettingDao
    ) {
        // 1. Seed Settings if empty
        val currentSetting = settingDao.getSettingDirect()
        if (currentSetting == null) {
            val defaultSetting = AppSetting(
                id = 1,
                schoolName = "مدرسة النهى الابتدائية للبنات",
                schoolLogoSeed = 3,
                workStartTime = "07:30",
                workEndTime = "13:30",
                gracePeriodMinutes = 15,
                weekendDays = "الجمعة,السبت",
                selectedThemeIndex = 0, // الوردي المشرق
                appLockEnabled = false,
                appLockPin = "1234",
                preventScreenshots = true
            )
            settingDao.saveSetting(defaultSetting)
        }

        // 2. Seed Employees if empty
        // Check if employees database is empty
        val hasEmployees = employeeDao.getEmployeeByCode("1001") != null
        if (!hasEmployees) {
            val employees = listOf(
                Employee(
                    name = "أ. فاطمة أحمد الغامدي",
                    employeeId = "1001",
                    department = "الإدارة العليا",
                    jobTitle = "مديرة المدرسة",
                    phone = "0501112222",
                    isActive = true,
                    hireDate = "2018-09-01",
                    notes = "المشرفة العامة وصاحبة صلاحية القفل والفتح",
                    isBiometricLinked = true
                ),
                Employee(
                    name = "أ. سارة عبد الله الحربي",
                    employeeId = "1002",
                    department = "الوكالة والخدمات",
                    jobTitle = "وكيلة شؤون المعلمات",
                    phone = "0503334444",
                    isActive = true,
                    hireDate = "2020-01-15",
                    notes = "مسؤولة التقارير الأسبوعية",
                    isBiometricLinked = true
                ),
                Employee(
                    name = "أمل محمد الشهري",
                    employeeId = "1003",
                    department = "اللغة العربية",
                    jobTitle = "معلمة لغة عربية",
                    phone = "0505556666",
                    isActive = true,
                    hireDate = "2021-08-20",
                    notes = "معلمة الصفوف الأولية والمشرفة الإذاعية",
                    isBiometricLinked = false
                ),
                Employee(
                    name = "منى صالح العتيبي",
                    employeeId = "1004",
                    department = "العلوم والرياضيات",
                    jobTitle = "معلمة رياضيات",
                    phone = "0507778888",
                    isActive = true,
                    hireDate = "2022-02-10",
                    notes = "رائدة الفصل الدراسي الثالث",
                    isBiometricLinked = true
                ),
                Employee(
                    name = "خلود علي الشمري",
                    employeeId = "1005",
                    department = "العلوم والرياضيات",
                    jobTitle = "معلمة علوم والأحياء",
                    phone = "0509990000",
                    isActive = true,
                    hireDate = "2022-09-01",
                    notes = "مسؤولة مختبر العلوم للبنات",
                    isBiometricLinked = false
                ),
                Employee(
                    name = "ريم خالد الدوسري",
                    employeeId = "1006",
                    department = "الخدمات الطلابية",
                    jobTitle = "موجهة طلابية",
                    phone = "0551122334",
                    isActive = true,
                    hireDate = "2019-11-05",
                    notes = "الإرشاد والتوجيه النفسي للطالبات",
                    isBiometricLinked = true
                ),
                Employee(
                    name = "نورة فهد السبيعي",
                    employeeId = "1007",
                    department = "السكرتارية والإدارة",
                    jobTitle = "مسؤولة القبول والتسجيل",
                    phone = "0554433221",
                    isActive = true,
                    hireDate = "2023-01-05",
                    notes = "شؤون الطالبات الجدد",
                    isBiometricLinked = false
                ),
                Employee(
                    name = "بدرية سليمان القحطاني",
                    employeeId = "1008",
                    department = "التربية البدنية والأسرية",
                    jobTitle = "معلمة تربية أسرية",
                    phone = "0556677889",
                    isActive = false, // موقوفة للتجربة
                    hireDate = "2024-02-01",
                    notes = "في إجازة رعاية مولود",
                    isBiometricLinked = false
                )
            )

            for (emp in employees) {
                employeeDao.insertEmployee(emp)
            }

            // 3. Seed historical attendance logs
            // Generate historical dates (Yesterday, 2 days ago, 3 days ago, 4 days ago)
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val cal = Calendar.getInstance()

            // Map of logs to generate (relative days, employeeId, name, checkInHour, checkOutHour)
            // Let's create beautiful data for the last 4 school days.
            val seedLogs = listOf(
                // Day -1 (Yesterday)
                SeedLogConfig(-1, "1001", "أ. فاطمة أحمد الغامدي", "07:15", "13:35"),
                SeedLogConfig(-1, "1002", "أ. سارة عبد الله الحربي", "07:25", "13:42"),
                SeedLogConfig(-1, "1003", "أمل محمد الشهري", "07:48", "13:30"), // متأخرة
                SeedLogConfig(-1, "1004", "منى صالح العتيبي", "07:10", "13:30"),
                SeedLogConfig(-1, "1006", "ريم خالد الدوسري", "07:28", "13:35"),
                
                // Day -2 (2 days ago)
                SeedLogConfig(-2, "1001", "أ. فاطمة أحمد الغامدي", "07:20", "13:40"),
                SeedLogConfig(-2, "1002", "أ. سارة عبد الله الحربي", "07:15", "13:32"),
                SeedLogConfig(-2, "1003", "أمل محمد الشهري", "07:24", "13:30"),
                SeedLogConfig(-2, "1004", "منى صالح العتيبي", "07:45", "13:05"), // متأخرة + انصراف مبكر
                SeedLogConfig(-2, "1005", "خلود علي الشمري", "07:20", "13:30"),
                SeedLogConfig(-2, "1006", "ريم خالد الدوسري", "07:12", "13:30"),

                // Day -3 (3 days ago)
                SeedLogConfig(-3, "1001", "أ. فاطمة أحمد الغامدي", "07:10", "13:30"),
                SeedLogConfig(-3, "1002", "أ. سارة عبد الله الحربي", "07:22", "13:30"),
                SeedLogConfig(-3, "1003", "أمل محمد الشهري", "07:28", "13:35"),
                SeedLogConfig(-3, "1004", "منى صالح العتيبي", "07:18", "13:32"),
                SeedLogConfig(-3, "1005", "خلود علي الشمري", "07:55", "13:30"), // متأخرة
                SeedLogConfig(-3, "1006", "ريم خالد الدوسري", "07:26", "13:45"),

                // Day -4 (4 days ago)
                SeedLogConfig(-4, "1001", "أ. فاطمة أحمد الغامدي", "07:14", "13:35"),
                SeedLogConfig(-4, "1002", "أ. سارة عبد الله الحربي", "07:19", "13:30"),
                SeedLogConfig(-4, "1003", "أمل محمد الشهري", "07:25", "13:30"),
                SeedLogConfig(-4, "1004", "منى صالح العتيبي", "07:15", "13:30"),
                SeedLogConfig(-4, "1005", "خلود علي الشمري", "07:22", "13:35"),
                SeedLogConfig(-4, "1006", "ريم خالد الدوسري", "07:29", "13:30")
            )

            for (logConfig in seedLogs) {
                // Determine if this is a weekend day (Skip Friday & Saturday)
                cal.time = java.util.Date()
                cal.add(Calendar.DAY_OF_YEAR, logConfig.relativeDays)
                val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
                if (dayOfWeek == Calendar.FRIDAY || dayOfWeek == Calendar.SATURDAY) {
                    continue // Skip seeding on weekends to keep statistics neat
                }

                val dateStr = sdf.format(cal.time)

                // 1. Check In (حضور)
                val inCal = Calendar.getInstance()
                inCal.time = cal.time
                val inParts = logConfig.checkIn.split(":")
                inCal.set(Calendar.HOUR_OF_DAY, inParts[0].toInt())
                inCal.set(Calendar.MINUTE, inParts[1].toInt())
                inCal.set(Calendar.SECOND, 0)
                
                val inStatus = if (inParts[0].toInt() > 7 || (inParts[0].toInt() == 7 && inParts[1].toInt() > 45)) {
                    "متأخر"
                } else {
                    "منتظم"
                }

                attendanceDao.insertLog(
                    AttendanceLog(
                        employeeId = logConfig.employeeId,
                        employeeName = logConfig.name,
                        timestamp = inCal.timeInMillis,
                        dateString = dateStr,
                        type = "حضور",
                        status = inStatus
                    )
                )

                // 2. Check Out (انصراف)
                val outCal = Calendar.getInstance()
                outCal.time = cal.time
                val outParts = logConfig.checkOut.split(":")
                outCal.set(Calendar.HOUR_OF_DAY, outParts[0].toInt())
                outCal.set(Calendar.MINUTE, outParts[1].toInt())
                outCal.set(Calendar.SECOND, 0)

                val outStatus = if (outParts[0].toInt() < 13 || (outParts[0].toInt() == 13 && outParts[1].toInt() < 30)) {
                    "انصراف مبكر"
                } else {
                    "منتظم"
                }

                attendanceDao.insertLog(
                    AttendanceLog(
                        employeeId = logConfig.employeeId,
                        employeeName = logConfig.name,
                        timestamp = outCal.timeInMillis,
                        dateString = dateStr,
                        type = "انصراف",
                        status = outStatus
                    )
                )
            }
        }
    }

    private data class SeedLogConfig(
        val relativeDays: Int,
        val employeeId: String,
        val name: String,
        val checkIn: String,
        val checkOut: String
    )
}
