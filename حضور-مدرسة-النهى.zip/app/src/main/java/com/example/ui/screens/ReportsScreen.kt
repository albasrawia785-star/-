package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceLog
import com.example.data.Employee
import com.example.ui.AppViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: AppViewModel) {
    val allLogs by viewModel.allLogs.collectAsState()
    val allEmployees by viewModel.allEmployees.collectAsState()
    val logsByDate by viewModel.logsBySelectedDate.collectAsState()
    val selectedDate by viewModel.selectedReportDate.collectAsState()

    var activeTabState by remember { mutableStateOf(0) } // 0 = Daily Logs, 1 = Employee Stats
    var searchQuery by remember { mutableStateOf("") }
    
    // Employee selection for statistics
    var selectedEmployeeCode by remember { mutableStateOf("") }
    var showEmpDropdown by remember { mutableStateOf(false) }

    // Helper for formatted dates
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val arabicLocale = Locale("ar")
    val displaySdf = SimpleDateFormat("EEEE, d MMMM yyyy", arabicLocale)

    // Date navigation
    fun navigateDate(days: Int) {
        try {
            val date = sdf.parse(selectedDate) ?: Date()
            val cal = Calendar.getInstance()
            cal.time = date
            cal.add(Calendar.DAY_OF_YEAR, days)
            viewModel.selectReportDate(sdf.format(cal.time))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Safe top inset
        Spacer(modifier = Modifier.height(24.dp))

        // Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "سجل التقارير والإحصائيات",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Right
                )
                Text(
                    text = "إحصائيات انضباط الموظفات وحساب ساعات العمل بدقة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Icon(
                imageVector = Icons.Default.Assessment,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Report Screen Tabs
        TabRow(
            selectedTabIndex = activeTabState,
            modifier = Modifier.fillMaxWidth().testTag("reports_tab_row"),
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(
                selected = activeTabState == 0,
                onClick = { activeTabState = 0 },
                text = { Text("سجل المدرسة اليومي", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Today, contentDescription = null) },
                modifier = Modifier.testTag("daily_reports_tab")
            )
            Tab(
                selected = activeTabState == 1,
                onClick = { activeTabState = 1 },
                text = { Text("إحصائيات الموظفة", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Person, contentDescription = null) },
                modifier = Modifier.testTag("staff_reports_tab")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTabState == 0) {
            // --- TAB 1: DAILY SCHOOL LOGS ---
            
            // Date Stepper
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = { navigateDate(-1) }, modifier = Modifier.testTag("prev_date_btn")) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "اليوم السابق")
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        val parsedDate = remember(selectedDate) {
                            try { sdf.parse(selectedDate) } catch (e: Exception) { Date() }
                        }
                        Text(
                            text = displaySdf.format(parsedDate),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = selectedDate,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }

                    IconButton(onClick = { navigateDate(1) }, modifier = Modifier.testTag("next_date_btn")) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "اليوم التالي")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search input for logs
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("ابحثي عن موظفة باليوم المحدد...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Summary stats for the selected date
            val totalIn = remember(logsByDate) { logsByDate.filter { it.type == "حضور" }.size }
            val totalOut = remember(logsByDate) { logsByDate.filter { it.type == "انصراف" }.size }
            val totalLate = remember(logsByDate) { logsByDate.filter { it.type == "حضور" && it.status == "متأخر" }.size }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InfoBadge(label = "حضور: $totalIn", color = Color(0xFF2E7D32), modifier = Modifier.weight(1f))
                InfoBadge(label = "انصراف: $totalOut", color = Color(0xFF546E7A), modifier = Modifier.weight(1f))
                InfoBadge(label = "تأخير: $totalLate", color = Color(0xFFEF6C00), modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(12.dp))

            val filteredLogs = remember(logsByDate, searchQuery) {
                logsByDate.filter { it.employeeName.contains(searchQuery, ignoreCase = true) || it.employeeId.contains(searchQuery) }
            }

            // Logs list
            if (filteredLogs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد أي عمليات حضور أو انصراف مسجلة في هذا التاريخ.",
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredLogs) { log ->
                        LogItemCard(log)
                    }
                }
            }
        } else {
            // --- TAB 2: INDIVIDUAL STAFF STATISTICS ---
            
            // Choose Employee Dropdown selector
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = if (selectedEmployeeCode.isEmpty()) "اضغطي لاختيار الموظفة..." 
                            else allEmployees.find { it.employeeId == selectedEmployeeCode }?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("اختر الموظفة لعرض تقريرها") },
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showEmpDropdown = true }
                        .testTag("employee_report_dropdown"),
                    shape = RoundedCornerShape(10.dp)
                )
                
                DropdownMenu(
                    expanded = showEmpDropdown,
                    onDismissRequest = { showEmpDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    allEmployees.forEach { emp ->
                        DropdownMenuItem(
                            text = { Text("${emp.name} (رقم: ${emp.employeeId})") },
                            onClick = {
                                selectedEmployeeCode = emp.employeeId
                                showEmpDropdown = false
                            },
                            modifier = Modifier.testTag("dropdown_item_${emp.employeeId}")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedEmployeeCode.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "يرجى اختيار موظفة من القائمة أعلاه لعرض تقرير الحضور والغياب وساعات العمل المفصل لها.",
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(32.dp)
                    )
                }
            } else {
                val emp = remember(selectedEmployeeCode, allEmployees) {
                    allEmployees.find { it.employeeId == selectedEmployeeCode }
                }

                if (emp != null) {
                    // Extract logs for selected employee
                    val empLogs = remember(allLogs, selectedEmployeeCode) {
                        allLogs.filter { it.employeeId == selectedEmployeeCode }
                    }

                    // Calculate stats
                    val checkIns = empLogs.filter { it.type == "حضور" }
                    val checkOuts = empLogs.filter { it.type == "انصراف" }
                    
                    val daysPresent = checkIns.map { it.dateString }.distinct().size
                    val totalLates = checkIns.filter { it.status == "متأخر" }.size
                    val totalEarlyOuts = checkOuts.filter { it.status == "انصراف مبكر" }.size

                    // Calculate working hours dynamically
                    // Match check-ins and check-outs on the same day
                    val totalWorkingHours = remember(empLogs) {
                        var hours = 0.0
                        val logsByDay = empLogs.groupBy { it.dateString }
                        for ((_, dayLogs) in logsByDay) {
                            val checkIn = dayLogs.find { it.type == "حضور" }
                            val checkOut = dayLogs.find { it.type == "انصراف" }
                            if (checkIn != null && checkOut != null) {
                                val diffMs = checkOut.timestamp - checkIn.timestamp
                                if (diffMs > 0) {
                                    hours += (diffMs.toDouble() / 1000.0 / 3600.0)
                                }
                            }
                        }
                        hours
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        // Profile Info
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(emp.name.take(2), fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(emp.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("${emp.jobTitle} • ${emp.department}", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                                        Text("تاريخ التعيين: ${emp.hireDate}", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                                    }
                                }
                            }
                        }

                        // Statistics grid
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    ReportStatBox(title = "أيام الحضور", value = "$daysPresent يوم", color = Color(0xFF2E7D32), modifier = Modifier.weight(1f))
                                    ReportStatBox(title = "مرات التأخير", value = "$totalLates مرة", color = Color(0xFFEF6C00), modifier = Modifier.weight(1f))
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    ReportStatBox(title = "انصراف مبكر", value = "$totalEarlyOuts مرة", color = Color(0xFFC62828), modifier = Modifier.weight(1f))
                                    ReportStatBox(title = "ساعات العمل", value = String.format("%.1f ساعة", totalWorkingHours), color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                                }
                            }
                        }

                        // Canvas Chart Visual representation of attendance statistics
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "الرسم البياني لتوزيع الحضور والغياب",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))

                                    // Let's draw horizontal custom progress bars inside a canvas
                                    val regularCount = (daysPresent - totalLates).coerceAtLeast(0)
                                    
                                    ChartBar(label = "حضور منتظم", count = regularCount, total = daysPresent.coerceAtLeast(1), color = Color(0xFF2E7D32))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    ChartBar(label = "حضور متأخر", count = totalLates, total = daysPresent.coerceAtLeast(1), color = Color(0xFFEF6C00))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    ChartBar(label = "انصراف مبكر", count = totalEarlyOuts, total = daysPresent.coerceAtLeast(1), color = Color(0xFFC62828))
                                }
                            }
                        }

                        // Log history header
                        item {
                            Text(
                                text = "تاريخ عمليات الموظفة التفصيلي",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }

                        // History logs
                        if (empLogs.isEmpty()) {
                            item {
                                Text("لا يوجد سجل حضور مسجل لهذه الموظفة حتى الآن.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                            }
                        } else {
                            items(empLogs) { log ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (log.type == "حضور") Icons.Default.Login else Icons.Default.Logout,
                                                contentDescription = null,
                                                tint = if (log.type == "حضور") Color(0xFF2E7D32) else Color(0xFF546E7A)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(log.type, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                                Text(log.dateString, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                            }
                                        }

                                        val logTimeSdf = SimpleDateFormat("hh:mm a", Locale("ar"))
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(logTimeSdf.format(Date(log.timestamp)), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                text = log.status,
                                                color = when (log.status) {
                                                    "منتظم" -> Color(0xFF2E7D32)
                                                    "متأخر" -> Color(0xFFE65100)
                                                    else -> Color(0xFFC62828)
                                                },
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InfoBadge(label: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(
            text = label,
            color = color,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 8.dp)
        )
    }
}

@Composable
fun ReportStatBox(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.shadow(1.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

@Composable
fun ChartBar(label: String, count: Int, total: Int, color: Color) {
    val progress = if (total == 0) 0f else (count.toFloat() / total.toFloat())
    val percent = if (total == 0) 0 else ((count.toFloat() / total.toFloat()) * 100).toInt()

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text("$count من $total ($percent%)", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        Spacer(modifier = Modifier.height(4.dp))
        
        Canvas(modifier = Modifier.fillMaxWidth().height(16.dp)) {
            val barWidth = size.width
            val barHeight = size.height
            val radius = CornerRadius(4.dp.toPx(), 4.dp.toPx())

            // Track background
            drawRoundRect(
                color = Color.LightGray.copy(alpha = 0.25f),
                size = Size(barWidth, barHeight),
                cornerRadius = radius
            )

            // Progress bar
            drawRoundRect(
                color = color,
                size = Size(barWidth * progress, barHeight),
                cornerRadius = radius
            )
        }
    }
}
