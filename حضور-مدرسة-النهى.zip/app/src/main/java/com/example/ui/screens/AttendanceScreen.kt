package com.example.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Employee
import com.example.data.LogResult
import com.example.ui.AppViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    viewModel: AppViewModel,
    onTriggerBiometric: (onSuccess: (String) -> Unit, onError: (String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val activeEmployees by viewModel.activeEmployees.collectAsState()
    
    // Live clock states
    var currentTimeString by remember { mutableStateOf("") }
    var currentDateString by remember { mutableStateOf("") }
    var currentDayArabic by remember { mutableStateOf("") }

    // Simulation toggle (critical for emulator/headless environment testing)
    var isSimulated by remember { mutableStateOf(true) }
    var showSimSheet by remember { mutableStateOf(false) }
    var selectedSimEmployee by remember { mutableStateOf<Employee?>(null) }

    // Last scan feedback state
    var showSuccessCard by remember { mutableStateOf(false) }
    var scanErrorText by remember { mutableStateOf("") }
    val lastResult by viewModel.attendanceResult.collectAsState()

    // Sound generator
    val toneGenerator = remember {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (e: Exception) {
            null
        }
    }

    // Update Clock Every Second
    LaunchedEffect(Unit) {
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val arabicLocale = Locale("ar")
        val dayFormat = SimpleDateFormat("EEEE, d MMMM yyyy", arabicLocale)

        while (true) {
            val now = Date()
            currentTimeString = timeFormat.format(now)
            currentDateString = dateFormat.format(now)
            currentDayArabic = dayFormat.format(now)
            delay(1000)
        }
    }

    // Success Sound & Auto Close logic
    LaunchedEffect(lastResult) {
        lastResult?.let { result ->
            if (result is LogResult.Success) {
                // Play Success Tone
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                showSuccessCard = true
                scanErrorText = ""
                delay(4000) // Auto dismiss success card after 4 seconds
                showSuccessCard = false
                viewModel.clearAttendanceResult()
            } else if (result is LogResult.Error) {
                scanErrorText = result.message
                showSuccessCard = false
            }
        }
    }

    // Pulsing Glowing Animation for Button
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.surface,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Safe inset spacer
        Spacer(modifier = Modifier.height(24.dp))

        // 1. School Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(4.dp, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = settings.schoolName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "نظام تسجيل الحضور والانصراف الذكي",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                // Custom school logo
                SchoolLogo(seed = settings.schoolLogoSeed, size = 64.dp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. Date & Clock Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = currentDayArabic,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = currentTimeString,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Normal,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.weight(0.5f))

        // 3. Central Biometric Touch Button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(240.dp)
                .testTag("biometric_tap_area")
        ) {
            // Pulse rings
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha))
                    .align(Alignment.Center)
            )
            Box(
                modifier = Modifier
                    .size(140.dp * pulseScale)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha * 0.5f))
                    .align(Alignment.Center)
            )

            // Main Trigger Button
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .shadow(12.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    )
                    .clickable {
                        if (isSimulated) {
                            showSimSheet = true
                        } else {
                            // Call native BiometricPrompt via activity callback
                            onTriggerBiometric(
                                { code -> viewModel.logAttendanceBiometric(code, {}) },
                                { error -> scanErrorText = error }
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Fingerprint,
                    contentDescription = "تسجيل الحضور/الانصراف",
                    tint = Color.White,
                    modifier = Modifier.size(64.dp)
                )
            }
        }

        Text(
            text = "اضغطي لتسجيل الحضور أو الانصراف",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(top = 16.dp)
        )

        Text(
            text = "يتعرف النظام تلقائياً على نوع العملية (حضور/انصراف) ويقيم حالة الانضباط أوفلاين.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
        )

        Spacer(modifier = Modifier.weight(0.5f))

        // 4. Biometric hardware type and simulator options
        Card(
            modifier = Modifier
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isSimulated) Icons.Default.Science else Icons.Default.Fingerprint,
                        contentDescription = null,
                        tint = if (isSimulated) MaterialTheme.colorScheme.primary else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSimulated) "وضع محاكاة البصمة نشط (للاختبار والتقييم)" else "استخدام بصمة الهاتف الحقيقية",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = isSimulated,
                    onCheckedChange = { isSimulated = it },
                    modifier = Modifier.testTag("simulator_switch")
                )
            }
        }

        // Show Error message if biometric fails
        if (scanErrorText.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.ErrorOutline, contentDescription = "خطأ", tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = scanErrorText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { scanErrorText = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // --- SUCCESS OVERLAY DIALOG (M3 design) ---
    if (showSuccessCard && lastResult is LogResult.Success) {
        val success = lastResult as LogResult.Success
        AlertDialog(
            onDismissRequest = {
                showSuccessCard = false
                viewModel.clearAttendanceResult()
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessCard = false
                        viewModel.clearAttendanceResult()
                    },
                    modifier = Modifier.fillMaxWidth().testTag("close_success_dialog")
                ) {
                    Text("تم", fontWeight = FontWeight.Bold)
                }
            },
            icon = {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "نجاح",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "تم تسجيل ${success.log.type} بنجاح",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Employee photo placeholder or seed drawable
                    Box(
                        modifier = Modifier
                            .size(96.dp)
                            .shadow(4.dp, CircleShape)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = success.employee.name.take(3).trim(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = success.employee.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "${success.employee.jobTitle} - ${success.employee.department}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "وقت العملية:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray
                        )
                        val logTimeSdf = SimpleDateFormat("hh:mm a", Locale("ar"))
                        Text(
                            text = logTimeSdf.format(Date(success.log.timestamp)),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "حالة الانضباط:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray
                        )
                        AssistChip(
                            onClick = {},
                            label = { Text(success.log.status) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = when (success.log.status) {
                                    "منتظم" -> Color(0xFFE8F5E9)
                                    else -> Color(0xFFFFEBEE)
                                },
                                labelColor = when (success.log.status) {
                                    "منتظم" -> Color(0xFF2E7D32)
                                    else -> Color(0xFFC62828)
                                }
                            )
                        )
                    }
                }
            },
            shape = RoundedCornerShape(28.dp),
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier
                .padding(28.dp)
                .testTag("attendance_success_dialog")
        )
    }

    // --- SIMULATOR BOTTOM SHEET ---
    if (showSimSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSimSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "محاكاة قارئ بصمة الإصبع والوجه",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "اختر الموظفة التي تريد محاكاة بصمتها لتسجيل الحضور/الانصراف اليوم:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                )

                if (activeEmployees.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد موظفات نشطات في المدرسة لتجربة المحاكاة. يرجى إضافة موظفة أولاً.",
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)
                    ) {
                        LazyColumn(
                            contentPadding = PaddingValues(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(activeEmployees) { emp ->
                                val isSelected = selectedSimEmployee?.id == emp.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                            else Color.Transparent
                                        )
                                        .clickable { selectedSimEmployee = emp }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isSelected) MaterialTheme.colorScheme.primary
                                                    else MaterialTheme.colorScheme.outlineVariant
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = emp.name.take(2),
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = emp.name,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Text(
                                                text = "الرقم الوظيفي: ${emp.employeeId} - ${emp.jobTitle}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.Gray
                                            )
                                        }
                                    }
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "محدد",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        selectedSimEmployee?.let { emp ->
                            viewModel.logAttendanceBiometric(emp.employeeId) {
                                showSimSheet = false
                            }
                        }
                    },
                    enabled = selectedSimEmployee != null,
                    modifier = Modifier.fillMaxWidth().testTag("simulate_fingerprint_confirm")
                ) {
                    Icon(Icons.Filled.Fingerprint, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("محاكاة البصمة الآن", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

/**
 * beautiful procedurally drawn school logo in Jetpack Compose Canvas
 */
@Composable
fun SchoolLogo(seed: Int, size: Dp) {
    val themeColor = MaterialTheme.colorScheme.primary
    val themeColorSecondary = MaterialTheme.colorScheme.secondary
    val themeColorTertiary = MaterialTheme.colorScheme.tertiary
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface

    Canvas(modifier = Modifier.size(size)) {
        val canvasWidth = this.size.width
        val canvasHeight = this.size.height

        // 1. Draw outer crest / shield
        drawCircle(
            color = themeColor.copy(alpha = 0.1f),
            radius = canvasWidth * 0.48f,
            center = Offset(canvasWidth / 2f, canvasHeight / 2f)
        )
        drawCircle(
            color = themeColor,
            radius = canvasWidth * 0.44f,
            center = Offset(canvasWidth / 2f, canvasHeight / 2f),
            style = Stroke(width = 3.dp.toPx())
        )

        // 2. Draw Book Pages
        val bookWidth = canvasWidth * 0.45f
        val bookHeight = canvasHeight * 0.25f
        val startX = (canvasWidth - bookWidth) / 2f
        val startY = canvasHeight * 0.4f

        // Procedural emblem shape: Shield with girls school minaret or star
        drawCircle(
            color = themeColorSecondary,
            radius = canvasWidth * 0.08f,
            center = Offset(canvasWidth / 2f, canvasHeight * 0.35f)
        )

        // Draw book sheets as simple beautiful vectors
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(canvasWidth * 0.25f, canvasHeight * 0.55f)
            quadraticTo(canvasWidth * 0.38f, canvasHeight * 0.48f, canvasWidth * 0.5f, canvasHeight * 0.55f)
            quadraticTo(canvasWidth * 0.62f, canvasHeight * 0.48f, canvasWidth * 0.75f, canvasHeight * 0.55f)
            lineTo(canvasWidth * 0.75f, canvasHeight * 0.68f)
            quadraticTo(canvasWidth * 0.62f, canvasHeight * 0.61f, canvasWidth * 0.5f, canvasHeight * 0.68f)
            quadraticTo(canvasWidth * 0.38f, canvasHeight * 0.61f, canvasWidth * 0.25f, canvasHeight * 0.68f)
            close()
        }
        drawPath(path, color = themeColorSecondary.copy(alpha = 0.85f))

        // Center binding line
        drawLine(
            color = themeColorTertiary,
            start = Offset(canvasWidth / 2f, canvasHeight * 0.52f),
            end = Offset(canvasWidth / 2f, canvasHeight * 0.69f),
            strokeWidth = 2.dp.toPx()
        )

        // Small decorative rays (sun or education light rays)
        for (i in 0 until 5) {
            val angle = Math.toRadians((180 + i * 45).toDouble())
            val rx = canvasWidth / 2f + Math.cos(angle).toFloat() * (canvasWidth * 0.22f)
            val ry = canvasHeight * 0.35f + Math.sin(angle).toFloat() * (canvasHeight * 0.22f)
            drawCircle(
                color = themeColorSecondary,
                radius = 2.dp.toPx(),
                center = Offset(rx, ry)
            )
        }
    }
}
