package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppSetting
import com.example.ui.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val currentSetting by viewModel.settings.collectAsState()

    // Form states
    var schoolName by remember { mutableStateOf("") }
    var workStartTime by remember { mutableStateOf("") }
    var workEndTime by remember { mutableStateOf("") }
    var gracePeriod by remember { mutableStateOf("") }
    var weekendDays by remember { mutableStateOf("") }
    var appLockPin by remember { mutableStateOf("") }
    var appLockEnabled by remember { mutableStateOf(false) }
    var preventScreenshots by remember { mutableStateOf(true) }
    var schoolLogoSeed by remember { mutableStateOf(3) }
    var selectedThemeIndex by remember { mutableStateOf(0) }

    // Dialog states for Backup/Restore
    var showBackupDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }
    var restoreJsonInput by remember { mutableStateOf("") }

    // Sync form states with database loaded values
    LaunchedEffect(currentSetting) {
        schoolName = currentSetting.schoolName
        workStartTime = currentSetting.workStartTime
        workEndTime = currentSetting.workEndTime
        gracePeriod = currentSetting.gracePeriodMinutes.toString()
        weekendDays = currentSetting.weekendDays
        appLockPin = currentSetting.appLockPin
        appLockEnabled = currentSetting.appLockEnabled
        preventScreenshots = currentSetting.preventScreenshots
        schoolLogoSeed = currentSetting.schoolLogoSeed
        selectedThemeIndex = currentSetting.selectedThemeIndex
    }

    // Themes names and description
    val themeOptions = listOf(
        ThemeOption("وردي النهى الزهري", "اللون الرسمي والمشرق لمدارس البنات", Color(0xFFD81B60), 0),
        ThemeOption("زمردي الغابات", "أخضر زمردي هادئ ومريح للعين", Color(0xFF00796B), 1),
        ThemeOption("كحلي ملكي وقور", "كحلي داكن رسمي للمؤسسات والشركات", Color(0xFF1A237E), 2),
        ThemeOption("أزرق كلاسيك", "أزرق صافي ذكي وحديث", Color(0xFF0288D1), 3)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 84.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe inset
        item { Spacer(modifier = Modifier.height(24.dp)) }

        // Settings Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "الإعدادات العامة للنظام",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "تخصيص الدوام، ألوان التطبيق، الأمان وإدارة النسخ الاحتياطي",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // 1. School Profile Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("هوية مدرسة النهى", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    OutlinedTextField(
                        value = schoolName,
                        onValueChange = { schoolName = it },
                        label = { Text("اسم المدرسة الرسمي") },
                        modifier = Modifier.fillMaxWidth().testTag("settings_school_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Seed modifier for School Logo
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("تعديل شعار المدرسة الدائري:", style = MaterialTheme.typography.bodyMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (schoolLogoSeed > 1) schoolLogoSeed-- }) {
                                Icon(Icons.Default.Remove, contentDescription = "السابق")
                            }
                            Text("$schoolLogoSeed", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 8.dp))
                            IconButton(onClick = { if (schoolLogoSeed < 10) schoolLogoSeed++ }) {
                                Icon(Icons.Default.Add, contentDescription = "التالي")
                            }
                        }
                    }
                }
            }
        }

        // 2. Work Schedule Configuration Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("مواعيد وقواعد الدوام الرسمي", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = workStartTime,
                            onValueChange = { workStartTime = it },
                            label = { Text("وقت بداية الدوام") },
                            placeholder = { Text("07:30") },
                            modifier = Modifier.weight(1f).testTag("settings_start_time"),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = workEndTime,
                            onValueChange = { workEndTime = it },
                            label = { Text("وقت نهاية الدوام") },
                            placeholder = { Text("13:30") },
                            modifier = Modifier.weight(1f).testTag("settings_end_time"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = gracePeriod,
                            onValueChange = { gracePeriod = it },
                            label = { Text("فترة السماح بالدقائق") },
                            placeholder = { Text("15") },
                            modifier = Modifier.weight(1.2f).testTag("settings_grace_period"),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = weekendDays,
                            onValueChange = { weekendDays = it },
                            label = { Text("أيام العطل الأسبوعية") },
                            placeholder = { Text("الجمعة,السبت") },
                            modifier = Modifier.weight(1.5f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }
        }

        // 3. Application Color Themes
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("مظهر وألوان التطبيق", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Grid of Theme choices
                    themeOptions.forEach { t ->
                        val isSelected = selectedThemeIndex == t.index
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    2.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                                    else Color.Transparent
                                )
                                .clickable { selectedThemeIndex = t.index }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(t.color)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(t.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(t.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }
                            }
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedThemeIndex = t.index },
                                modifier = Modifier.testTag("theme_radio_${t.index}")
                            )
                        }
                    }
                }
            }
        }

        // 4. Security Configuration Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ميزات الأمان والحماية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Prevent screenshots switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("منع لقطات الشاشة لحفظ الخصوصية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("يحجب تصوير شاشة التطبيق لحماية صور وبيانات المعلمات.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Switch(checked = preventScreenshots, onCheckedChange = { preventScreenshots = it })
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // App lock switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("قفل لوحة الإدارة برمز PIN أو البصمة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("يمنع وصول أي معلّمة للإعدادات أو قوائم الموظفات إلا للمديرة.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Switch(checked = appLockEnabled, onCheckedChange = { appLockEnabled = it })
                    }

                    if (appLockEnabled) {
                        OutlinedTextField(
                            value = appLockPin,
                            onValueChange = { if (it.length <= 8) appLockPin = it },
                            label = { Text("الرمز السري للقفل (PIN) الخاص بالمديرة") },
                            modifier = Modifier.fillMaxWidth().testTag("settings_pin_input"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }
        }

        // 5. Save settings action button
        item {
            Button(
                onClick = {
                    val finalSetting = AppSetting(
                        id = 1,
                        schoolName = schoolName,
                        schoolLogoSeed = schoolLogoSeed,
                        workStartTime = workStartTime,
                        workEndTime = workEndTime,
                        gracePeriodMinutes = gracePeriod.toIntOrNull() ?: 15,
                        weekendDays = weekendDays,
                        selectedThemeIndex = selectedThemeIndex,
                        appLockEnabled = appLockEnabled,
                        appLockPin = appLockPin,
                        preventScreenshots = preventScreenshots
                    )
                    viewModel.updateSchoolSettings(finalSetting)
                    Toast.makeText(context, "تم حفظ الإعدادات وتحديث المظهر أوفلاين بنجاح!", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.fillMaxWidth().testTag("settings_save_btn")
            ) {
                Icon(Icons.Filled.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("حفظ وتطبيق جميع التغييرات", fontWeight = FontWeight.Bold)
            }
        }

        // 6. Offline Data Backup & Restore Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("النسخ الاحتياطي واستعادة البيانات أوفلاين", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }

                    Text(
                        text = "يتيح لك التطبيق نقل كافة البيانات وقوائم الموظفات وسجلات الحضور والغياب يدويًا إلى أي هاتف آخر بنسبة 100% بدون إنترنت.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                backupJsonText = viewModel.exportBackupJson()
                                showBackupDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.weight(1f).testTag("backup_export_btn")
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير نسخة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                restoreJsonInput = ""
                                showRestoreDialog = true
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.weight(1f).testTag("backup_restore_btn")
                        ) {
                            Icon(Icons.Filled.Upload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("استيراد نسخة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // --- DIALOG: EXPORT BACKUP JSON ---
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("AlNuhaBackup", backupJsonText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "تم نسخ كود النسخة الاحتياطية بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("نسخ كود الاحتياط كاملاً")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBackupDialog = false }) {
                    Text("إغلاق")
                }
            },
            title = {
                Text(
                    text = "رمز النسخة الاحتياطية الجاهز",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("قومي بنسخ النص أدناه والاحتفاظ به بأمان، أو إرساله للهاتف الآخر لاستيراده:")
                    OutlinedTextField(
                        value = backupJsonText,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        textStyle = MaterialTheme.typography.bodySmall,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    )
                }
            },
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.testTag("export_backup_dialog")
        )
    }

    // --- DIALOG: IMPORT RESTORE JSON ---
    if (showRestoreDialog) {
        var isRestoreError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreJsonInput.trim().isEmpty()) {
                            isRestoreError = true
                            return@Button
                        }
                        val isSuccess = viewModel.importBackupJson(restoreJsonInput)
                        if (isSuccess) {
                            Toast.makeText(context, "تم استيراد النسخة الاحتياطية أوفلاين وتحديث البيانات بنجاح!", Toast.LENGTH_LONG).show()
                            showRestoreDialog = false
                        } else {
                            isRestoreError = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("confirm_restore_btn")
                ) {
                    Icon(Icons.Filled.Backup, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("استعادة وتحديث قاعدة البيانات")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("إلغاء")
                }
            },
            title = {
                Text(
                    text = "استيراد نسخة احتياطية",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الصقي كود النسخة الاحتياطية الذي قمتي بتصديره مسبقاً لاستعادة كافة سجلات المعلمات والعمليات:")
                    OutlinedTextField(
                        value = restoreJsonInput,
                        onValueChange = {
                            restoreJsonInput = it
                            isRestoreError = false
                        },
                        isError = isRestoreError,
                        placeholder = { Text("الصقي كود JSON الاحتياطي هنا...") },
                        modifier = Modifier.fillMaxWidth().height(180.dp).testTag("restore_json_input"),
                        textStyle = MaterialTheme.typography.bodySmall
                    )
                    if (isRestoreError) {
                        Text(
                            text = "الكود المدخل غير صالح أو فارغ. يرجى التأكد من نسخ كود احتياطي صحيح بالكامل.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }
}

data class ThemeOption(
    val title: String,
    val description: String,
    val color: Color,
    val index: Int
)
