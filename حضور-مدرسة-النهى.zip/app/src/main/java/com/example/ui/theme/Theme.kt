package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Light Color Schemes
private val RoseLight = lightColorScheme(
    primary = RosePrimaryLight,
    secondary = RoseSecondaryLight,
    tertiary = RoseTertiaryLight,
    background = RoseBackgroundLight,
    surface = RoseSurfaceLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF2E1A1D),
    onSurface = Color(0xFF2E1A1D)
)

private val EmeraldLight = lightColorScheme(
    primary = EmeraldPrimaryLight,
    secondary = EmeraldSecondaryLight,
    tertiary = EmeraldTertiaryLight,
    background = EmeraldBackgroundLight,
    surface = EmeraldSurfaceLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF0F1A18),
    onSurface = Color(0xFF0F1A18)
)

private val NavyLight = lightColorScheme(
    primary = NavyPrimaryLight,
    secondary = NavySecondaryLight,
    tertiary = NavyTertiaryLight,
    background = NavyBackgroundLight,
    surface = NavySurfaceLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF101220),
    onSurface = Color(0xFF101220)
)

private val BlueLight = lightColorScheme(
    primary = BluePrimaryLight,
    secondary = BlueSecondaryLight,
    tertiary = BlueTertiaryLight,
    background = BlueBackgroundLight,
    surface = BlueSurfaceLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF0E1A20),
    onSurface = Color(0xFF0E1A20)
)

// Dark Color Schemes
private val RoseDark = darkColorScheme(
    primary = RosePrimaryDark,
    secondary = RoseSecondaryDark,
    tertiary = RoseTertiaryDark,
    background = RoseBackgroundDark,
    surface = RoseSurfaceDark,
    onPrimary = Color(0xFF4A001B),
    onSecondary = Color(0xFF4A001B),
    onTertiary = Color(0xFF4A001B),
    onBackground = Color(0xFFFFECEF),
    onSurface = Color(0xFFFFECEF)
)

private val EmeraldDark = darkColorScheme(
    primary = EmeraldPrimaryDark,
    secondary = EmeraldSecondaryDark,
    tertiary = EmeraldTertiaryDark,
    background = EmeraldBackgroundDark,
    surface = EmeraldSurfaceDark,
    onPrimary = Color(0xFF003730),
    onSecondary = Color(0xFF003730),
    onTertiary = Color(0xFF003730),
    onBackground = Color(0xFFE0F2F1),
    onSurface = Color(0xFFE0F2F1)
)

private val NavyDark = darkColorScheme(
    primary = NavyPrimaryDark,
    secondary = NavySecondaryDark,
    tertiary = NavyTertiaryDark,
    background = NavyBackgroundDark,
    surface = NavySurfaceDark,
    onPrimary = Color(0xFF0A0E37),
    onSecondary = Color(0xFF0A0E37),
    onTertiary = Color(0xFF0A0E37),
    onBackground = Color(0xFFE8EAF6),
    onSurface = Color(0xFFE8EAF6)
)

private val BlueDark = darkColorScheme(
    primary = BluePrimaryDark,
    secondary = BlueSecondaryDark,
    tertiary = BlueTertiaryDark,
    background = BlueBackgroundDark,
    surface = BlueSurfaceDark,
    onPrimary = Color(0xFF00344F),
    onSecondary = Color(0xFF00344F),
    onTertiary = Color(0xFF00344F),
    onBackground = Color(0xFFE1F5FE),
    onSurface = Color(0xFFE1F5FE)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    themeIndex: Int = 0,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeIndex) {
        0 -> if (darkTheme) RoseDark else RoseLight
        1 -> if (darkTheme) EmeraldDark else EmeraldLight
        2 -> if (darkTheme) NavyDark else NavyLight
        3 -> if (darkTheme) BlueDark else BlueLight
        else -> if (darkTheme) RoseDark else RoseLight
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
