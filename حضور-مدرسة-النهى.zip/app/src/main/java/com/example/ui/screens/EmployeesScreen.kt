package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Employee
import com.example.ui.AppViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeesScreen(
    viewModel: AppViewModel,
    onTriggerBiometric: (onSuccess: (String) -> Unit, onError: (String) -> Unit) -> Unit
) {
    val employees by viewModel.allEmployees.collectAsState()
    
    var searchQuery by remember { mutableStateOf("") }
    var selectedDepartmentFilter by remember { mutableStateOf("الكل") }
    
    // Add/Edit sheet state
    var showFormSheet by remember { mutableStateOf(false) }
    var editingEmployee by remember { mutableStateOf<Employee?>(null) }
    
    // Biometric Pairing Dialog/Feedback state
    var showPairingSuccess by remember { mutableStateOf(false) }
    var pairedEmployeeName by remember { mutableStateOf("") }

    // Dropdowns options
    val departments = listOf("الكل", "الإدارة العليا", "الوكالة والخدمات", "اللغة العربية", "العلوم والرياضيات", "الخدمات الطلابية", "التربية البدنية والأسرية", "السكرتارية والإدارة")

    // Filtered employees
    val filteredEmployees = remember(employees, searchQuery, selectedDepartmentFilter) {
        employees.filter { emp ->
            val matchesSearch = emp.name.contains(searchQuery, ignoreCase = true) || 
                                emp.employeeId.contains(searchQuery) ||
                                emp.jobTitle.contains(searchQuery, ignoreCase = true)
            val matchesDept = selectedDepartmentFilter == "الكل" || emp.department == selectedDepartmentFilter
            matchesSearch && matchesDept
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Spacer for top insets
            Spacer(modifier = Modifier.height(24.dp))

            // Screen Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "إدارة ملفات الموظفات",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "تسجيل الموظفات، تعديل البيانات وربط البصمات بالجهاز",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Icon(
                    imageVector = Icons.Default.Badge,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("ابحثي باسم الموظفة أو الرقم الوظيفي...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("employee_search_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Department Filters (Horizontal Chips Row)
            ScrollableTabRow(
                selectedTabIndex = departments.indexOf(selectedDepartmentFilter).coerceAtLeast(0),
                edgePadding = 0.dp,
                divider = {},
                indicator = {},
                modifier = Modifier.fillMaxWidth()
            ) {
                departments.forEach { dept ->
                    val isSelected = selectedDepartmentFilter == dept
                    Tab(
                        selected = isSelected,
                        onClick = { selectedDepartmentFilter = dept },
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
                    ) {
                        SuggestionChip(
                            onClick = { selectedDepartmentFilter = dept },
                            label = { Text(dept, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                labelColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            border = if (isSelected) {
                                null
                            } else {
                                SuggestionChipDefaults.suggestionChipBorder(
                                    enabled = true,
                                    borderColor = Color.LightGray,
                                    borderWidth = 1.dp
                                )
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Employees List or Empty state
            if (filteredEmployees.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد نتائج مطابقة لبحثك",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray
                        )
                        Text(
                            text = "اضغطي على زر (+) بالأسفل لإضافة موظفة جديدة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).testTag("employees_list"),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredEmployees, key = { it.id }) { emp ->
                        EmployeeCard(
                            employee = emp,
                            onEdit = {
                                editingEmployee = emp
                                showFormSheet = true
                            },
                            onDelete = { viewModel.deleteEmployee(emp.id) },
                            onToggleActive = {
                                viewModel.saveEmployee(emp.copy(isActive = !emp.isActive)) {}
                            },
                            onLinkBiometric = {
                                // Trigger Biometric Prompt in main activity
                                onTriggerBiometric(
                                    {
                                        viewModel.pairBiometric(emp.employeeId, {
                                            pairedEmployeeName = emp.name
                                            showPairingSuccess = true
                                        }, {})
                                    },
                                    { /* Handle Error if needed */ }
                                )
                            },
                            onUnlinkBiometric = {
                                viewModel.unpairBiometric(emp.employeeId)
                            }
                        )
                    }
                }
            }
        }

        // Floating Action Button to Add Employee
        FloatingActionButton(
            onClick = {
                editingEmployee = null
                showFormSheet = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 90.dp, end = 24.dp)
                .testTag("add_employee_fab")
        ) {
            Icon(Icons.Filled.Add, contentDescription = "إضافة موظفة")
        }
    }

    // --- SUCCESS BIOMETRIC PAIRING DIALOG ---
    if (showPairingSuccess) {
        AlertDialog(
            onDismissRequest = { showPairingSuccess = false },
            confirmButton = {
                Button(onClick = { showPairingSuccess = false }, modifier = Modifier.fillMaxWidth()) {
                    Text("ممتاز", fontWeight = FontWeight.Bold)
                }
            },
            icon = {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                }
            },
            title = {
                Text(
                    text = "ربط البصمة بنجاح",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Text(
                    text = "تم ربط البصمة بنجاح بالموظفة ($pairedEmployeeName). يمكنها الآن استخدام البصمة أو الوجه لتسجيل حضورها وانصرافها.",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    // --- ADD / EDIT EMPLOYEE BOTTOM SHEET ---
    if (showFormSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFormSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            EmployeeForm(
                employee = editingEmployee,
                departments = departments.filter { it != "الكل" },
                onDismiss = { showFormSheet = false },
                onSave = { emp ->
                    viewModel.saveEmployee(emp) {
                        showFormSheet = false
                    }
                }
            )
        }
    }
}

@Composable
fun EmployeeCard(
    employee: Employee,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleActive: () -> Unit,
    onLinkBiometric: () -> Unit,
    onUnlinkBiometric: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp))
            .border(
                1.dp,
                if (employee.isActive) Color.Transparent else Color.Red.copy(alpha = 0.2f),
                RoundedCornerShape(16.dp)
            )
            .testTag("employee_card_${employee.employeeId}"),
        colors = CardDefaults.cardColors(
            containerColor = if (employee.isActive) MaterialTheme.colorScheme.surface 
                             else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Profile picture or placeholder
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(
                                if (employee.isActive) MaterialTheme.colorScheme.primaryContainer 
                                else Color.LightGray
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = employee.name.take(3).trim(),
                            fontWeight = FontWeight.Bold,
                            color = if (employee.isActive) MaterialTheme.colorScheme.onPrimaryContainer else Color.DarkGray,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = employee.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "الرقم الوظيفي: ${employee.employeeId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            // Status Badge
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (employee.isActive) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                modifier = Modifier.padding(1.dp)
                            ) {
                                Text(
                                    text = if (employee.isActive) "فعالة" else "موقوفة",
                                    color = if (employee.isActive) Color(0xFF2E7D32) else Color(0xFFC62828),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = "تفاصيل"
                    )
                }
            }

            // Quick display subtitle
            Text(
                text = "${employee.jobTitle} • ${employee.department}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )

            // Expanded details block
            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    DetailItem(label = "رقم الهاتف", value = employee.phone, icon = Icons.Outlined.Phone)
                    DetailItem(label = "تاريخ التعيين", value = employee.hireDate, icon = Icons.Outlined.CalendarToday)
                    if (employee.notes.isNotEmpty()) {
                        DetailItem(label = "ملاحظات", value = employee.notes, icon = Icons.Outlined.Notes)
                    }

                    // Biometric Status Detail
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ربط البصمة بالهاتف:", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                        }
                        Text(
                            text = if (employee.isBiometricLinked) "تم الربط" else "غير مرتبطة",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (employee.isBiometricLinked) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Link Biometric Button
                        if (!employee.isBiometricLinked) {
                            Button(
                                onClick = onLinkBiometric,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1.5f).testTag("link_biometric_btn")
                            ) {
                                Icon(Icons.Filled.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ربط البصمة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            OutlinedButton(
                                onClick = onUnlinkBiometric,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                                modifier = Modifier.weight(1.5f)
                            ) {
                                Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إلغاء ربط البصمة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 2. Edit Info Button
                        OutlinedButton(
                            onClick = onEdit,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).testTag("edit_employee_btn")
                        ) {
                            Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تعديل", fontSize = 12.sp)
                        }

                        // 3. More options (Toggle block / Delete)
                        IconButton(
                            onClick = onToggleActive,
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                imageVector = if (employee.isActive) Icons.Filled.Block else Icons.Filled.CheckCircle,
                                contentDescription = if (employee.isActive) "إيقاف" else "تفعيل",
                                tint = if (employee.isActive) Color(0xFFC62828) else Color(0xFF2E7D32)
                            )
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "حذف الموظفة",
                                tint = Color.Red
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailItem(label: String, value: String, icon: ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "$label: ", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeeForm(
    employee: Employee?,
    departments: List<String>,
    onDismiss: () -> Unit,
    onSave: (Employee) -> Unit
) {
    var name by remember { mutableStateOf(employee?.name ?: "") }
    var employeeId by remember { mutableStateOf(employee?.employeeId ?: "") }
    var department by remember { mutableStateOf(employee?.department ?: departments.first()) }
    var jobTitle by remember { mutableStateOf(employee?.jobTitle ?: "") }
    var phone by remember { mutableStateOf(employee?.phone ?: "") }
    var hireDate by remember { mutableStateOf(employee?.hireDate ?: "") }
    var notes by remember { mutableStateOf(employee?.notes ?: "") }
    var isActive by remember { mutableStateOf(employee?.isActive ?: true) }

    // Dropdown expanding
    var deptDropdownExpanded by remember { mutableStateOf(false) }

    // Validation
    var nameError by remember { mutableStateOf(false) }
    var codeError by remember { mutableStateOf(false) }

    // Default current hire date if empty
    LaunchedEffect(Unit) {
        if (hireDate.isEmpty()) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            hireDate = sdf.format(Date())
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = if (employee == null) "تسجيل موظفة جديدة" else "تعديل بيانات الموظفة",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Right,
            modifier = Modifier.fillMaxWidth()
        )

        Divider(color = MaterialTheme.colorScheme.outlineVariant)

        // 1. Name Field
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                nameError = it.trim().isEmpty()
            },
            label = { Text("الاسم الكامل للموظفة *") },
            isError = nameError,
            modifier = Modifier.fillMaxWidth().testTag("form_name_input"),
            shape = RoundedCornerShape(10.dp)
        )
        if (nameError) {
            Text("الاسم مطلوب لحفظ الملف", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        // 2. Employee Code (Job ID)
        OutlinedTextField(
            value = employeeId,
            onValueChange = {
                employeeId = it
                codeError = it.trim().isEmpty()
            },
            label = { Text("الرقم الوظيفي المميز *") },
            enabled = employee == null, // Lock code on edit
            isError = codeError,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("form_id_input"),
            shape = RoundedCornerShape(10.dp)
        )
        if (codeError) {
            Text("الرقم الوظيفي مطلوب لحفظ الملف", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 3. Department dropdown
            ExposedDropdownMenuBox(
                expanded = deptDropdownExpanded,
                onExpandedChange = { deptDropdownExpanded = !deptDropdownExpanded },
                modifier = Modifier.weight(1f)
            ) {
                OutlinedTextField(
                    value = department,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("القسم") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deptDropdownExpanded) },
                    modifier = Modifier.menuAnchor(),
                    shape = RoundedCornerShape(10.dp)
                )
                ExposedDropdownMenu(
                    expanded = deptDropdownExpanded,
                    onDismissRequest = { deptDropdownExpanded = false }
                ) {
                    departments.forEach { dept ->
                        DropdownMenuItem(
                            text = { Text(dept) },
                            onClick = {
                                department = dept
                                deptDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // 4. Job Title
            OutlinedTextField(
                value = jobTitle,
                onValueChange = { jobTitle = it },
                label = { Text("المسمى الوظيفي *") },
                modifier = Modifier.weight(1f).testTag("form_title_input"),
                shape = RoundedCornerShape(10.dp)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 5. Phone
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("رقم الهاتف") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.weight(1.2f),
                shape = RoundedCornerShape(10.dp)
            )

            // 6. Hire Date
            OutlinedTextField(
                value = hireDate,
                onValueChange = { hireDate = it },
                label = { Text("تاريخ التعيين") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            )
        }

        // 7. Notes
        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            label = { Text("ملاحظات إضافية") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 2,
            shape = RoundedCornerShape(10.dp)
        )

        // 8. Is Active Switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("حالة الملف الوظيفي (فعال لتسجيل الدخول)", fontWeight = FontWeight.Bold)
            Switch(checked = isActive, onCheckedChange = { isActive = it })
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Save Button
        Button(
            onClick = {
                if (name.trim().isEmpty()) {
                    nameError = true
                    return@Button
                }
                if (employeeId.trim().isEmpty()) {
                    codeError = true
                    return@Button
                }
                
                val toSave = Employee(
                    id = employee?.id ?: 0,
                    name = name,
                    employeeId = employeeId,
                    department = department,
                    jobTitle = jobTitle,
                    phone = phone,
                    isActive = isActive,
                    hireDate = hireDate,
                    notes = notes,
                    isBiometricLinked = employee?.isBiometricLinked ?: false
                )
                onSave(toSave)
            },
            modifier = Modifier.fillMaxWidth().testTag("form_submit_btn")
        ) {
            Text("حفظ الملف الموظفة", fontWeight = FontWeight.Bold)
        }
    }
}
