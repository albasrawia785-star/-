package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AppViewModel(
    application: Application,
    private val repository: EmployeeRepository
) : AndroidViewModel(application) {

    // Theme state
    private val _themeIndex = MutableStateFlow(0)
    val themeIndex: StateFlow<Int> = _themeIndex.asStateFlow()

    // Screen security state
    private val _adminUnlocked = MutableStateFlow(false)
    val adminUnlocked: StateFlow<Boolean> = _adminUnlocked.asStateFlow()

    // Selected Date for Report
    private val _selectedReportDate = MutableStateFlow("")
    val selectedReportDate: StateFlow<String> = _selectedReportDate.asStateFlow()

    init {
        // Fetch current date string
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        _selectedReportDate.value = sdf.format(Date())

        // Collect settings to sync theme index
        viewModelScope.launch {
            repository.appSetting.collect { setting ->
                setting?.let {
                    _themeIndex.value = it.selectedThemeIndex
                }
            }
        }
    }

    // Settings Flow
    val settings: StateFlow<AppSetting> = repository.appSetting
        .map { it ?: AppSetting() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSetting()
        )

    // Employees Flows
    val allEmployees: StateFlow<List<Employee>> = repository.allEmployees
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeEmployees: StateFlow<List<Employee>> = repository.activeEmployees
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Attendance Logs
    val allLogs: StateFlow<List<AttendanceLog>> = repository.allLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Logs filtered by selected date
    val logsBySelectedDate: StateFlow<List<AttendanceLog>> = _selectedReportDate
        .flatMapLatest { date ->
            repository.getLogsByDate(date)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Live status update for logging feedback
    private val _attendanceResult = MutableStateFlow<LogResult?>(null)
    val attendanceResult: StateFlow<LogResult?> = _attendanceResult.asStateFlow()

    // Security Unlock
    fun checkAndUnlockWithPin(pin: String): Boolean {
        val currentSettings = settings.value
        return if (pin == currentSettings.appLockPin) {
            _adminUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun setAdminUnlocked(unlocked: Boolean) {
        _adminUnlocked.value = unlocked
    }

    fun relockAdmin() {
        _adminUnlocked.value = false
    }

    // Set Report Date
    fun selectReportDate(dateString: String) {
        _selectedReportDate.value = dateString
    }

    // Register / Update Employee
    fun saveEmployee(employee: Employee, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.insertEmployee(employee)
            onComplete()
        }
    }

    // Delete Employee
    fun deleteEmployee(id: Int) {
        viewModelScope.launch {
            repository.deleteEmployee(id)
        }
    }

    // Link biometric to employee
    fun pairBiometric(employeeId: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val emp = repository.getEmployeeByCode(employeeId)
            if (emp != null) {
                val updatedEmp = emp.copy(isBiometricLinked = true)
                repository.insertEmployee(updatedEmp)
                onSuccess()
            } else {
                onError("الموظفة غير مسجلة")
            }
        }
    }

    // Unlink biometric from employee
    fun unpairBiometric(employeeId: String) {
        viewModelScope.launch {
            val emp = repository.getEmployeeByCode(employeeId)
            if (emp != null) {
                val updatedEmp = emp.copy(isBiometricLinked = false)
                repository.insertEmployee(updatedEmp)
            }
        }
    }

    // Main biometric check-in logic
    fun logAttendanceBiometric(employeeCode: String, onCompleted: (LogResult) -> Unit) {
        viewModelScope.launch {
            val result = repository.logAttendance(employeeCode)
            _attendanceResult.value = result
            onCompleted(result)
        }
    }

    fun clearAttendanceResult() {
        _attendanceResult.value = null
    }

    // Update School Settings
    fun updateSchoolSettings(newSetting: AppSetting) {
        viewModelScope.launch {
            repository.saveSetting(newSetting)
            _themeIndex.value = newSetting.selectedThemeIndex
        }
    }

    fun clearAllLogs() {
        viewModelScope.launch {
            repository.clearAllLogs()
        }
    }

    // --- JSON Backup & Restore System (100% Offline & Clean) ---

    fun exportBackupJson(): String {
        val sb = StringBuilder()
        sb.append("{\n")
        
        // 1. Export settings
        val s = settings.value
        sb.append("  \"settings\": {\n")
        sb.append("    \"schoolName\": \"${escapeJson(s.schoolName)}\",\n")
        sb.append("    \"schoolLogoSeed\": ${s.schoolLogoSeed},\n")
        sb.append("    \"workStartTime\": \"${s.workStartTime}\",\n")
        sb.append("    \"workEndTime\": \"${s.workEndTime}\",\n")
        sb.append("    \"gracePeriodMinutes\": ${s.gracePeriodMinutes},\n")
        sb.append("    \"weekendDays\": \"${escapeJson(s.weekendDays)}\",\n")
        sb.append("    \"selectedThemeIndex\": ${s.selectedThemeIndex},\n")
        sb.append("    \"appLockEnabled\": ${s.appLockEnabled},\n")
        sb.append("    \"appLockPin\": \"${s.appLockPin}\",\n")
        sb.append("    \"preventScreenshots\": ${s.preventScreenshots}\n")
        sb.append("  },\n")

        // 2. Export employees
        sb.append("  \"employees\": [\n")
        val emps = allEmployees.value
        emps.forEachIndexed { i, e ->
            sb.append("    {\n")
            sb.append("      \"name\": \"${escapeJson(e.name)}\",\n")
            sb.append("      \"employeeId\": \"${escapeJson(e.employeeId)}\",\n")
            sb.append("      \"department\": \"${escapeJson(e.department)}\",\n")
            sb.append("      \"jobTitle\": \"${escapeJson(e.jobTitle)}\",\n")
            sb.append("      \"phone\": \"${escapeJson(e.phone)}\",\n")
            sb.append("      \"isActive\": ${e.isActive},\n")
            sb.append("      \"hireDate\": \"${e.hireDate}\",\n")
            sb.append("      \"notes\": \"${escapeJson(e.notes)}\",\n")
            sb.append("      \"isBiometricLinked\": ${e.isBiometricLinked}\n")
            sb.append("    }${if (i == emps.size - 1) "" else ","}\n")
        }
        sb.append("  ],\n")

        // 3. Export logs
        sb.append("  \"logs\": [\n")
        val logs = allLogs.value
        logs.forEachIndexed { i, l ->
            sb.append("    {\n")
            sb.append("      \"employeeId\": \"${escapeJson(l.employeeId)}\",\n")
            sb.append("      \"employeeName\": \"${escapeJson(l.employeeName)}\",\n")
            sb.append("      \"timestamp\": ${l.timestamp},\n")
            sb.append("      \"dateString\": \"${l.dateString}\",\n")
            sb.append("      \"type\": \"${escapeJson(l.type)}\",\n")
            sb.append("      \"status\": \"${escapeJson(l.status)}\"\n")
            sb.append("    }${if (i == logs.size - 1) "" else ","}\n")
        }
        sb.append("  ]\n")
        sb.append("}")
        return sb.toString()
    }

    fun importBackupJson(jsonStr: String): Boolean {
        return try {
            // Simple robust regex extraction to avoid complex library issues
            // Extract and save Settings
            val schoolName = extractJsonField(jsonStr, "schoolName") ?: "مدرسة النهى الابتدائية للبنات"
            val logoSeed = extractJsonField(jsonStr, "schoolLogoSeed")?.toIntOrNull() ?: 3
            val workStart = extractJsonField(jsonStr, "workStartTime") ?: "07:30"
            val workEnd = extractJsonField(jsonStr, "workEndTime") ?: "13:30"
            val grace = extractJsonField(jsonStr, "gracePeriodMinutes")?.toIntOrNull() ?: 15
            val weekend = extractJsonField(jsonStr, "weekendDays") ?: "الجمعة,السبت"
            val themeIndexVal = extractJsonField(jsonStr, "selectedThemeIndex")?.toIntOrNull() ?: 0
            val lockEnabled = extractJsonField(jsonStr, "appLockEnabled")?.toBoolean() ?: false
            val pin = extractJsonField(jsonStr, "appLockPin") ?: "1234"
            val prevScreen = extractJsonField(jsonStr, "preventScreenshots")?.toBoolean() ?: true

            val newSetting = AppSetting(
                id = 1,
                schoolName = schoolName,
                schoolLogoSeed = logoSeed,
                workStartTime = workStart,
                workEndTime = workEnd,
                gracePeriodMinutes = grace,
                weekendDays = weekend,
                selectedThemeIndex = themeIndexVal,
                appLockEnabled = lockEnabled,
                appLockPin = pin,
                preventScreenshots = prevScreen
            )

            viewModelScope.launch {
                repository.saveSetting(newSetting)
                _themeIndex.value = themeIndexVal

                // Parse and insert employees
                // Let's do robust line-by-line block matching for employees array
                val empBlocks = extractJsonObjects(jsonStr, "employees")
                for (eb in empBlocks) {
                    val eName = extractJsonField(eb, "name") ?: continue
                    val eCode = extractJsonField(eb, "employeeId") ?: continue
                    val eDept = extractJsonField(eb, "department") ?: "المعلمات"
                    val eTitle = extractJsonField(eb, "jobTitle") ?: "معلمة"
                    val ePhone = extractJsonField(eb, "phone") ?: ""
                    val eActive = extractJsonField(eb, "isActive")?.toBoolean() ?: true
                    val eHire = extractJsonField(eb, "hireDate") ?: "2026-01-01"
                    val eNotes = extractJsonField(eb, "notes") ?: ""
                    val eBio = extractJsonField(eb, "isBiometricLinked")?.toBoolean() ?: false

                    val existing = repository.getEmployeeByCode(eCode)
                    val emp = Employee(
                        id = existing?.id ?: 0,
                        name = eName,
                        employeeId = eCode,
                        department = eDept,
                        jobTitle = eTitle,
                        phone = ePhone,
                        isActive = eActive,
                        hireDate = eHire,
                        notes = eNotes,
                        isBiometricLinked = eBio
                    )
                    repository.insertEmployee(emp)
                }

                // Parse and insert attendance logs
                val logBlocks = extractJsonObjects(jsonStr, "logs")
                for (lb in logBlocks) {
                    val lCode = extractJsonField(lb, "employeeId") ?: continue
                    val lName = extractJsonField(lb, "employeeName") ?: ""
                    val lTime = extractJsonField(lb, "timestamp")?.toLongOrNull() ?: System.currentTimeMillis()
                    val lDateStr = extractJsonField(lb, "dateString") ?: "2026-07-05"
                    val lType = extractJsonField(lb, "type") ?: "حضور"
                    val lStatus = extractJsonField(lb, "status") ?: "منتظم"

                    repository.insertLogDirect(
                        AttendanceLog(
                            employeeId = lCode,
                            employeeName = lName,
                            timestamp = lTime,
                            dateString = lDateStr,
                            type = lType,
                            status = lStatus
                        )
                    )
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
    }

    private fun extractJsonField(json: String, field: String): String? {
        val pattern = "\"$field\"\\s*:\\s*\"([^\"]*)\"".toRegex()
        val match = pattern.find(json)
        if (match != null) {
            return match.groupValues[1]
        }
        val numPattern = "\"$field\"\\s*:\\s*([^,\n}]*)".toRegex()
        val numMatch = numPattern.find(json)
        if (numMatch != null) {
            return numMatch.groupValues[1].trim()
        }
        return null
    }

    private fun extractJsonObjects(json: String, arrayKey: String): List<String> {
        val result = mutableListOf<String>()
        try {
            val startIndex = json.indexOf("\"$arrayKey\"")
            if (startIndex == -1) return emptyList()
            
            val arrayStart = json.indexOf("[", startIndex)
            if (arrayStart == -1) return emptyList()
            
            var braceCount = 0
            var inObject = false
            var currentObj = java.lang.StringBuilder()
            
            for (i in arrayStart until json.length) {
                val c = json[i]
                if (c == '[') {
                    if (braceCount == 0) {
                        braceCount++
                        continue
                    }
                }
                if (c == '{') {
                    inObject = true
                    braceCount++
                }
                if (inObject) {
                    currentObj.append(c)
                }
                if (c == '}') {
                    braceCount--
                    if (braceCount == 1) { // End of object
                        result.add(currentObj.toString())
                        currentObj = java.lang.StringBuilder()
                        inObject = false
                    }
                }
                if (c == ']' && braceCount == 1) {
                    break
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }
}

class AppViewModelFactory(
    private val application: Application,
    private val repository: EmployeeRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AppViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
