package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Attendance : Screen("attendance", "تسجيل الحضور", Icons.Filled.Fingerprint)
    object Dashboard : Screen("dashboard", "لوحة التحكم", Icons.Filled.Dashboard)
    object Employees : Screen("employees", "الموظفات", Icons.Filled.People)
    object Reports : Screen("reports", "التقارير", Icons.Filled.Assessment)
    object Settings : Screen("settings", "الإعدادات", Icons.Filled.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: AppViewModel,
    onTriggerBiometric: (onSuccess: (String) -> Unit, onError: (String) -> Unit) -> Unit
) {
    val selectedThemeIndex by viewModel.themeIndex.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val adminUnlocked by viewModel.adminUnlocked.collectAsState()

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Screen list
    val navigationItems = listOf(
        Screen.Attendance,
        Screen.Dashboard,
        Screen.Employees,
        Screen.Reports,
        Screen.Settings
    )

    // RTL language direction enforcement for flawless Arabic layouts
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MyApplicationTheme(themeIndex = selectedThemeIndex) {
            Scaffold(
                bottomBar = {
                    NavigationBar(
                        modifier = Modifier
                            .shadow(16.dp, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                            .testTag("main_navigation_bar"),
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        navigationItems.forEach { screen ->
                            val isSelected = currentRoute == screen.route
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    // Security lock logic:
                                    // If navigating to Admin screens (Dashboard, Employees, Reports, Settings)
                                    // and app lock is enabled, check if admin is unlocked.
                                    if (screen != Screen.Attendance && settings.appLockEnabled && !adminUnlocked) {
                                        // Navigate but overlay lock gate or trigger prompt
                                        navController.navigate("security_lock/${screen.route}") {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    } else {
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                label = {
                                    Text(
                                        text = screen.title,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 11.sp
                                    )
                                },
                                icon = {
                                    Icon(
                                        imageVector = screen.icon,
                                        contentDescription = screen.title,
                                        modifier = Modifier.size(24.dp)
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray
                                ),
                                modifier = Modifier.testTag("nav_item_${screen.route}")
                            )
                        }
                    }
                },
                contentWindowInsets = WindowInsets.navigationBars
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Attendance.route,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable(Screen.Attendance.route) {
                            AttendanceScreen(viewModel, onTriggerBiometric)
                        }
                        composable(Screen.Dashboard.route) {
                            DashboardScreen(viewModel)
                        }
                        composable(Screen.Employees.route) {
                            EmployeesScreen(viewModel, onTriggerBiometric)
                        }
                        composable(Screen.Reports.route) {
                            ReportsScreen(viewModel)
                        }
                        composable(Screen.Settings.route) {
                            SettingsScreen(viewModel)
                        }
                        
                        // Security lock overlay route
                        composable("security_lock/{targetRoute}") { backStackEntry ->
                            val target = backStackEntry.arguments?.getString("targetRoute") ?: Screen.Dashboard.route
                            SecurityLockScreen(
                                viewModel = viewModel,
                                onUnlockSuccess = {
                                    navController.navigate(target) {
                                        popUpTo("security_lock/{targetRoute}") { inclusive = true }
                                        launchSingleTop = true
                                    }
                                },
                                onCancel = {
                                    navController.navigate(Screen.Attendance.route) {
                                        popUpTo(Screen.Attendance.route) { inclusive = true }
                                    }
                                },
                                onTriggerBiometric = onTriggerBiometric
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Gate Lock Screen protecting the administration sections
 */
@Composable
fun SecurityLockScreen(
    viewModel: AppViewModel,
    onUnlockSuccess: () -> Unit,
    onCancel: () -> Unit,
    onTriggerBiometric: (onSuccess: (String) -> Unit, onError: (String) -> Unit) -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    var enteredPin by remember { mutableStateOf("") }
    var pinErrorText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "بوابة التحقق الأمنية للمديرة",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Text(
            text = "يرجى مسح بصمة المديرة أو إدخال رمز PIN للدخول للوحة التحكم.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Display Dots for Pin
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(bottom = 24.dp)
        ) {
            for (i in 0 until 4) {
                val isFilled = enteredPin.length > i
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(
                            if (isFilled) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        )
                )
            }
        }

        if (pinErrorText.isNotEmpty()) {
            Text(
                text = pinErrorText,
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Custom Numeric Pin Pad
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("مسح", "0", "مسح الكل")
            )

            keys.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    row.forEach { key ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1.5f)
                                .shadow(2.dp, RoundedCornerShape(12.dp))
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (key == "مسح" || key == "مسح الكل") MaterialTheme.colorScheme.surfaceVariant
                                    else MaterialTheme.colorScheme.surface
                                )
                                .clickable {
                                    when (key) {
                                        "مسح" -> {
                                            if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                            pinErrorText = ""
                                        }
                                        "مسح الكل" -> {
                                            enteredPin = ""
                                            pinErrorText = ""
                                        }
                                        else -> {
                                            if (enteredPin.length < 4) {
                                                enteredPin += key
                                                pinErrorText = ""
                                                
                                                // Automatic checking when 4 digits are completed
                                                if (enteredPin.length == 4) {
                                                    val success = viewModel.checkAndUnlockWithPin(enteredPin)
                                                    if (success) {
                                                        onUnlockSuccess()
                                                    } else {
                                                        enteredPin = ""
                                                        pinErrorText = "رمز PIN غير صحيح. يرجى المحاولة مجدداً."
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                .testTag("pin_key_$key"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = key,
                                fontWeight = FontWeight.Bold,
                                fontSize = if (key.length > 1) 14.sp else 22.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Biometric alternative trigger button
        Button(
            onClick = {
                // Instantly unlock in emulator or let them trigger a simulated prompt
                onTriggerBiometric(
                    {
                        // Match with principal code "1001" or any success
                        viewModel.setAdminUnlocked(true)
                        onUnlockSuccess()
                    },
                    { error ->
                        pinErrorText = "فشلت البصمة: $error"
                    }
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
            modifier = Modifier.widthIn(min = 200.dp).testTag("biometric_manager_unlock")
        ) {
            Icon(Icons.Filled.Fingerprint, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("فتح ببصمة المديرة", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(onClick = onCancel, modifier = Modifier.testTag("cancel_unlock_btn")) {
            Text("إلغاء والعودة للرئيسية", color = Color.Gray)
        }
    }
}
