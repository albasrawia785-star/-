package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 1. Al-Nuha Rose Pink Theme (ورد النهى - الافتراضي)
val RosePrimaryLight = Color(0xFFD81B60)
val RoseSecondaryLight = Color(0xFFAD1457)
val RoseTertiaryLight = Color(0xFFC2185B)
val RoseBackgroundLight = Color(0xFFFFFBFC)
val RoseSurfaceLight = Color(0xFFFFF1F3)

val RosePrimaryDark = Color(0xFFFFB2C5)
val RoseSecondaryDark = Color(0xFFFF85A3)
val RoseTertiaryDark = Color(0xFFF48FB1)
val RoseBackgroundDark = Color(0xFF1E1416)
val RoseSurfaceDark = Color(0xFF2D1B1E)

// 2. Emerald Forest Theme (الزمردي الطبيعي)
val EmeraldPrimaryLight = Color(0xFF00796B)
val EmeraldSecondaryLight = Color(0xFF004D40)
val EmeraldTertiaryLight = Color(0xFF00897B)
val EmeraldBackgroundLight = Color(0xFFF4FBFB)
val EmeraldSurfaceLight = Color(0xFFE0F2F1)

val EmeraldPrimaryDark = Color(0xFF80CBC4)
val EmeraldSecondaryDark = Color(0xFF4DB6AC)
val EmeraldTertiaryDark = Color(0xFF26A69A)
val EmeraldBackgroundDark = Color(0xFF0E1A18)
val EmeraldSurfaceDark = Color(0xFF172C28)

// 3. Royal Navy Theme (الكحلي الملكي)
val NavyPrimaryLight = Color(0xFF1A237E)
val NavySecondaryLight = Color(0xFF283593)
val NavyTertiaryLight = Color(0xFF3F51B5)
val NavyBackgroundLight = Color(0xFFF5F6FC)
val NavySurfaceLight = Color(0xFFE8EAF6)

val NavyPrimaryDark = Color(0xFF9FA8DA)
val NavySecondaryDark = Color(0xFF7986CB)
val NavyTertiaryDark = Color(0xFF5C6BC0)
val NavyBackgroundDark = Color(0xFF0F101A)
val NavySurfaceDark = Color(0xFF181C30)

// 4. Classic Blue Theme (الأزرق الكلاسيكي)
val BluePrimaryLight = Color(0xFF0288D1)
val BlueSecondaryLight = Color(0xFF0277BD)
val BlueTertiaryLight = Color(0xFF039BE5)
val BlueBackgroundLight = Color(0xFFF4FAFD)
val BlueSurfaceLight = Color(0xFFE1F5FE)

val BluePrimaryDark = Color(0xFF81D4FA)
val BlueSecondaryDark = Color(0xFF4FC3F7)
val BlueTertiaryDark = Color(0xFF29B6F6)
val BlueBackgroundDark = Color(0xFF0F191E)
val BlueSurfaceDark = Color(0xFF182830)
