package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceLog
import com.example.data.Employee
import com.example.ui.AppViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(viewModel: AppViewModel) {
    val activeEmployees by viewModel.activeEmployees.collectAsState()
    val allLogs by viewModel.allLogs.collectAsState()

    // Filter today's logs
    val todayDateString = remember {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.format(Date())
    }

    val todayLogs = remember(allLogs) {
        allLogs.filter { it.dateString == todayDateString }
    }

    // Calculations
    val totalActiveCount = activeEmployees.size
    
    // Unique check-ins today
    val presentCount = remember(todayLogs) {
        todayLogs.filter { it.type == "حضور" }.map { it.employeeId }.distinct().size
    }

    val lateCount = remember(todayLogs) {
        todayLogs.filter { it.type == "حضور" && it.status == "متأخر" }.map { it.employeeId }.distinct().size
    }

    val absentCount = remember(totalActiveCount, presentCount) {
        val count = totalActiveCount - presentCount
        if (count < 0) 0 else count
    }

    val attendanceRate = remember(totalActiveCount, presentCount) {
        if (totalActiveCount == 0) 0f else (presentCount.toFloat() / totalActiveCount.toFloat())
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe inset spacer
        item { Spacer(modifier = Modifier.height(24.dp)) }

        // Dashboard Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "لوحة التحكم والمتابعة اليومية",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "متابعة فورية للحضور والانضباط اليومي للموظفات",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Icon(
                    imageVector = Icons.Outlined.Dashboard,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // Stats Row (2x2 Grid using columns & rows)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "إجمالي الكادر",
                        value = totalActiveCount.toString(),
                        unit = "موظفة",
                        icon = Icons.Default.People,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f).testTag("kpi_total_employees")
                    )
                    StatCard(
                        title = "الحضور اليوم",
                        value = presentCount.toString(),
                        unit = "حاضرة",
                        icon = Icons.Default.CheckCircle,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f).testTag("kpi_present_today")
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "الغياب اليوم",
                        value = absentCount.toString(),
                        unit = "متغيبة",
                        icon = Icons.Default.Cancel,
                        color = Color(0xFFC62828),
                        modifier = Modifier.weight(1f).testTag("kpi_absent_today")
                    )
                    StatCard(
                        title = "المتأخرات",
                        value = lateCount.toString(),
                        unit = "موظفة",
                        icon = Icons.Default.Schedule,
                        color = Color(0xFFEF6C00),
                        modifier = Modifier.weight(1f).testTag("kpi_late_today")
                    )
                }
            }
        }

        // Attendance Progress Rate Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "نسبة الانضباط والحضور",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "معدل الحضور مقارنة بإجمالي القوة العاملة للمدرسة اليوم.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = attendanceRate,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (attendanceRate > 0.8f) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        )
                    }

                    Spacer(modifier = Modifier.width(20.dp))

                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "${(attendanceRate * 100).toInt()}%",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp,
                            color = if (attendanceRate > 0.8f) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                        )
                        CircularProgressIndicator(
                            progress = attendanceRate,
                            modifier = Modifier.size(80.dp),
                            color = if (attendanceRate > 0.8f) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                            strokeWidth = 6.dp,
                            trackColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
            }
        }

        // Recent Logs Section Title
        item {
            Text(
                text = "آخر عمليات تسجيل الحضور والانصراف اليوم",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Logs List or Empty State
        if (todayLogs.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا توجد عمليات حضور أو انصراف مسجلة اليوم حتى الآن",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "اذهبي لشاشة تسجيل الحضور لتسجيل البصمة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        } else {
            items(todayLogs.take(10)) { log ->
                LogItemCard(log)
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    unit: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .shadow(2.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray,
                    textAlign = TextAlign.Right
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Start
            ) {
                Text(
                    text = " $unit",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun LogItemCard(log: AttendanceLog) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                // Circular status icon
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (log.type == "حضور") Color(0xFFE8F5E9) else Color(0xFFECEFF1)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (log.type == "حضور") Icons.Default.Login else Icons.Default.Logout,
                        contentDescription = null,
                        tint = if (log.type == "حضور") Color(0xFF2E7D32) else Color(0xFF546E7A),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = log.employeeName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "الرقم الوظيفي: ${log.employeeId}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            // Time and status chips
            Column(horizontalAlignment = Alignment.End) {
                val timeSdf = SimpleDateFormat("hh:mm a", Locale("ar"))
                Text(
                    text = timeSdf.format(Date(log.timestamp)),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(4.dp))

                // Custom status label
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (log.status) {
                        "منتظم" -> Color(0xFFE8F5E9)
                        "متأخر" -> Color(0xFFFFF3E0)
                        else -> Color(0xFFFFEBEE)
                    },
                    modifier = Modifier.padding(1.dp)
                ) {
                    Text(
                        text = log.status,
                        color = when (log.status) {
                            "منتظم" -> Color(0xFF2E7D32)
                            "متأخر" -> Color(0xFFE65100)
                            else -> Color(0xFFC62828)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
