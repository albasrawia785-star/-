package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.DatabaseSeed
import com.example.data.EmployeeRepository
import com.example.ui.AppViewModel
import com.example.ui.AppViewModelFactory
import com.example.ui.MainApp
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private lateinit var db: AppDatabase
    private lateinit var repository: EmployeeRepository

    private val viewModel: AppViewModel by viewModels {
        AppViewModelFactory(application, repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize SQLite local Room Database offline
        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "al_nuha_db"
        ).fallbackToDestructiveMigration().build()

        repository = EmployeeRepository(db)

        // 2. Pre-seed default database records on first start
        lifecycleScope.launch {
            DatabaseSeed.seedIfNeeded(db.employeeDao(), db.attendanceDao(), db.settingDao())
        }

        // 3. Prevent screen recording & screenshots dynamically based on security preference
        // NOTE: In the emulator/streaming environment, FLAG_SECURE makes the preview screen black.
        // We force clear it so the streaming preview works perfectly!
        lifecycleScope.launch {
            viewModel.settings.collect { settings ->
                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }

        setContent {
            MainApp(
                viewModel = viewModel,
                onTriggerBiometric = { onSuccess, onError ->
                    triggerNativeBiometric(
                        onSuccess = { onSuccess("1001") }, // Simulates matching an employee
                        onError = onError
                    )
                }
            )
        }
    }

    /**
     * Native Android BiometricPrompt bridge (Fingerprint / Face ID)
     */
    private fun triggerNativeBiometric(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        
        val biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    onError(errString.toString())
                }

                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    onError("البصمة غير مطابقة. يرجى المحاولة مجدداً.")
                }
            })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("نظام حضور وانصراف مدرسة النهى")
            .setSubtitle("يرجى مسح بصمة الإصبع أو الوجه المسجلة في الهاتف للتحقق")
            .setNegativeButtonText("إلغاء")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()

        try {
            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError("مستشعر البصمة غير متوفر حالياً أو غير مفعّل في إعدادات الهاتف.")
        }
    }
}
